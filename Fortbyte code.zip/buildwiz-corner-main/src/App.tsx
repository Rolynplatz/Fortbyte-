import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Index from "./pages/Index";
import Simulator from "./pages/Simulator";
import Library from "./pages/Library";
import Tutorials from "./pages/Tutorials";
import ModuleDetail from "./pages/ModuleDetail";
import LessonDetail from "./pages/LessonDetail";
import ComponentDetail from "./pages/ComponentDetail";
import BuildSaved from "./pages/BuildSaved";
import Quizzes from "./pages/Quizzes";
import QuizPlay from "./pages/QuizPlay";
import ComponentInfo from "./pages/ComponentInfo";
import Cart from "./pages/Cart";
import Forum from "./pages/Forum";
import Checkout from "./pages/Checkout";
import Compare from "./pages/Compare";
import Releases from "./pages/Releases";
import NewDiscussion from "./pages/NewDiscussion";
import Progress from "./pages/Progress";
import About from "./pages/About";
import Contact from "./pages/Contact";
import FAQ from "./pages/FAQ";
import Support from "./pages/Support";
import Search from "./pages/Search";
import Profile from "./pages/Profile";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/simulator" element={<Simulator />} />
          <Route path="/simulator/saved" element={<BuildSaved />} />
          <Route path="/library" element={<Library />} />
          <Route path="/library/:category" element={<ComponentDetail />} />
          <Route path="/library/:category/info" element={<ComponentInfo />} />
          <Route path="/cart" element={<Cart />} />
          <Route path="/tutorials" element={<Tutorials />} />
          <Route path="/tutorials/module/:moduleId" element={<ModuleDetail />} />
          <Route path="/tutorials/lesson/:lessonId" element={<LessonDetail />} />
          <Route path="/quizzes" element={<Quizzes />} />
          <Route path="/quizzes/:quizId" element={<QuizPlay />} />
          <Route path="/forum" element={<Forum />} />
          <Route path="/forum/new" element={<NewDiscussion />} />
          <Route path="/checkout" element={<Checkout />} />
          <Route path="/compare" element={<Compare />} />
          <Route path="/releases" element={<Releases />} />
          <Route path="/progress" element={<Progress />} />
          <Route path="/search" element={<Search />} />
          <Route path="/profile" element={<Profile />} />
          <Route path="/about" element={<About />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/faq" element={<FAQ />} />
          <Route path="/support" element={<Support />} />
          {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
